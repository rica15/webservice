package com.example.demo.process;

import javax.batch.api.chunk.ItemProcessor;

import com.example.demo.field.field;

public class fieldProcessor implements org.springframework.batch.item.ItemProcessor<field, field> {

	@Override
	public field process(field item) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	

}
