package com.example.demo.field;

public class field {
	private int Id;
	private String ORDER_ID;
	private String ORDER_DATE;
	private String SHIP_DATE;
	private String SHIP_MODE;
	private int QUANTITY;
	private int DISCOUNT;
	private int PROFIT;
	private String PRODUCT_ID;
	private String CUSTOMER_NAME;

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getORDER_ID() {
		return ORDER_ID;
	}

	public void setORDER_ID(String oRDER_ID) {
		ORDER_ID = oRDER_ID;
	}

	public String getORDER_DATE() {
		return ORDER_DATE;
	}

	public void setORDER_DATE(String oRDER_DATE) {
		ORDER_DATE = oRDER_DATE;
	}

	public String getSHIP_DATE() {
		return SHIP_DATE;
	}

	public void setSHIP_DATE(String sHIP_DATE) {
		SHIP_DATE = sHIP_DATE;
	}

	public String getSHIP_MODE() {
		return SHIP_MODE;
	}

	public void setSHIP_MODE(String sHIP_MODE) {
		SHIP_MODE = sHIP_MODE;
	}

	public int getQUANTITY() {
		return QUANTITY;
	}

	public void setQUANTITY(int qUANTITY) {
		QUANTITY = qUANTITY;
	}

	public int getDISCOUNT() {
		return DISCOUNT;
	}

	public void setDISCOUNT(int dISCOUNT) {
		DISCOUNT = dISCOUNT;
	}

	public int getPROFIT() {
		return PROFIT;
	}

	public void setPROFIT(int pROFIT) {
		PROFIT = pROFIT;
	}

	public String getPRODUCT_ID() {
		return PRODUCT_ID;
	}

	public void setPRODUCT_ID(String pRODUCT_ID) {
		PRODUCT_ID = pRODUCT_ID;
	}

	public String getCUSTOMER_NAME() {
		return CUSTOMER_NAME;
	}

	public void setCUSTOMER_NAME(String cUSTOMER_NAME) {
		CUSTOMER_NAME = cUSTOMER_NAME;
	}

	public String getCATEGORY() {
		return CATEGORY;
	}

	public void setCATEGORY(String cATEGORY) {
		CATEGORY = cATEGORY;
	}

	public String getCUSTOMER_ID() {
		return CUSTOMER_ID;
	}

	public void setCUSTOMER_ID(String cUSTOMER_ID) {
		CUSTOMER_ID = cUSTOMER_ID;
	}

	public String getPRODUCT_NAME() {
		return PRODUCT_NAME;
	}

	public void setPRODUCT_NAME(String pRODUCT_NAME) {
		PRODUCT_NAME = pRODUCT_NAME;
	}

	private String CATEGORY;
	private String CUSTOMER_ID;
	private String PRODUCT_NAME;

}
